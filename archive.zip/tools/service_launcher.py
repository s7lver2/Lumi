# tools/service_launcher.py
"""
Process-orchestration helpers for tools/installer_source.py: deciding how to
launch the inference service (native venv vs WSL2) and the worker, and
confirming they actually came up. No Python tests here per this project's
standing "no tests under tools/" preference — verify by running
`services/inference/venv/Scripts/python.exe tools/installer_source.py`
(or the compiled exe) and reading its output.
"""
import json
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

INFERENCE_PORT = 8000


def read_runtime_marker(root: Path) -> str:
    """Reads data/runtime-config.json written by apps/web/lib/runtime-marker.ts
    at the end of setup. Defaults to "windows" (INFERENCE_RUNTIME's own schema
    default, packages/shared-types/src/settings.ts) if setup hasn't completed
    yet, or the file is missing/unreadable for any other reason — a fresh
    clone with no marker file should degrade to "try the native venv path",
    not crash."""
    marker_path = root / "data" / "runtime-config.json"
    try:
        data = json.loads(marker_path.read_text(encoding="utf-8"))
        runtime = data.get("inferenceRuntime")
        return runtime if runtime in ("windows", "wsl") else "windows"
    except (OSError, ValueError):
        return "windows"

def _win_path_to_wsl(win_path: Path) -> str:
    # Mirrors apps/web/app/lib/wsl-path.ts's winPathToWsl exactly (same
    # regex-free approach: drive letter lowercased, backslashes to slashes).
    s = str(win_path.resolve())
    drive, rest = s.split(":", 1)
    return f"/mnt/{drive.lower()}{rest.replace(chr(92), '/')}"


def inference_command(root: Path, runtime: str) -> list[str] | None:
    """Returns the argv to launch uvicorn for the chosen runtime, or None if
    that runtime's venv doesn't exist yet (setup hasn't installed it) — the
    caller should skip starting inference rather than launch a command that's
    guaranteed to fail with "file not found"."""
    infer = root / "services" / "inference"
    if runtime == "wsl":
        venv_wsl = infer / "venv-wsl"
        if not venv_wsl.exists():
            return None
        infer_wsl = _win_path_to_wsl(infer)
        script = f"cd '{infer_wsl}' && venv-wsl/bin/uvicorn main:app --host 0.0.0.0 --port {INFERENCE_PORT}"
        return ["wsl.exe", "--", "bash", "-lc", script]
    venv = infer / "venv"
    if not venv.exists():
        return None
    python_exe = venv / "Scripts" / "python.exe"
    return [str(python_exe), "-m", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", str(INFERENCE_PORT)]


def worker_command(root: Path) -> list[str]:
    return ["pnpm", "--filter", "@netryx/worker", "start"]


def wait_for_http_ok(url: str, timeout_s: float, poll_interval_s: float = 1.0) -> bool:
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as resp:
                if resp.status < 400:
                    return True
        except (urllib.error.URLError, OSError):
            pass
        time.sleep(poll_interval_s)
    return False

def start_detached(cmd: list[str], cwd: Path) -> subprocess.Popen:
    # CREATE_NEW_PROCESS_GROUP so closing the installer's own console window
    # doesn't send Ctrl+C/Ctrl+Break to these children too — they're meant to
    # keep running as background services, not die with the installer.
    # NOTE: this only protects the native Windows process (python.exe /
    # pnpm.cmd / wsl.exe itself) from the console signal; if the runtime is
    # "wsl", the actual uvicorn process lives inside the WSL2 VM, which is
    # already independent of any Windows console by construction.
    creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0
    return subprocess.Popen(
        cmd, cwd=cwd, shell=(sys.platform == "win32" and cmd[0] not in ("wsl.exe",)),
        creationflags=creationflags,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )


def start_all_services(root: Path, log=print) -> dict[str, "subprocess.Popen | None"]:
    """Starts inference + worker (db is handled separately by
    installer_source.py's existing `docker compose up -d` call, which is
    already correct — see Task 3). Returns a dict of name -> Popen (or None
    if that service was skipped, e.g. inference venv not installed yet)."""
    started: dict[str, "subprocess.Popen | None"] = {}

    runtime = read_runtime_marker(root)
    infer_cmd = inference_command(root, runtime)
    if infer_cmd is None:
        log(f"Servicio de inferencia: entorno '{runtime}' no instalado todavía — omitido "
            f"(completa /setup y vuelve a abrir LumiInstaller.exe).")
        started["inference"] = None
    else:
        log(f"Arrancando servicio de inferencia ({runtime})...")
        started["inference"] = start_detached(infer_cmd, root / "services" / "inference")
        if wait_for_http_ok(f"http://localhost:{INFERENCE_PORT}/docs", timeout_s=45):
            log("Servicio de inferencia: listo.")
        else:
            log("Servicio de inferencia: no respondió a tiempo (puede seguir cargando modelos en segundo plano).")

    log("Arrancando worker...")
    started["worker"] = start_detached(worker_command(root), root)
    time.sleep(3)
    if started["worker"].poll() is None:
        log("Worker: en marcha.")
    else:
        log(f"Worker: terminó inmediatamente (código {started['worker'].returncode}) — revisa que 'pnpm install' se haya completado.")

    return started