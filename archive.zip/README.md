# Lumi

Street-level image geolocation. Self-hosted, Windows-native (with an optional
WSL2 fast path for the verification model — see `/setup`).

## For people who received a Lumi bundle (a `lumi-<version>.zip`)

Unzip it, then double-click **`LumiInstaller.exe`** at its root. It checks
you have Node.js + pnpm, Python 3, and Docker Desktop on your PATH, creates
`.env` from `.env.example` if you don't have one yet, runs `pnpm install`,
starts Postgres via `docker compose`, then starts the web app and opens your
browser on it. The first time, you'll land on `/setup` — a step-by-step
wizard that installs the inference service's Python dependencies, downloads
the model weights, sets up the database schema, and collects your Google
Street View API key.

## For maintainers: building a bundle

```bash
services/inference/venv/Scripts/pip.exe install pyinstaller   # once
services/inference/venv/Scripts/python.exe tools/build.py
```

Produces `dist/lumi-<version>.zip`: a clean snapshot of the project (source,
docs, configs — no `node_modules`, Python virtual environments, model-weight
caches, or `.git` history) with `LumiInstaller.exe` compiled and placed at
its root.

## Manual setup (no installer)

See `docs/` for the detailed sub-project specs and plans if you'd rather run
each piece by hand (`pnpm install`, `pnpm db:up`, `pnpm --filter @netryx/web dev`,
plus the inference service under `services/inference`).
