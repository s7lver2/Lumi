// apps/web/lib/search/run-refine.ts
import type { RefineResponse, SearchCandidate } from "@netryx/shared-types";
import type { RegionCandidate } from "./refine-retrieval";
import type { VerifyResult } from "../verify-client";
import type { ScoredCandidate, PersistRefineArgs } from "./refine-persist";

export interface RunRefineInput {
  searchId: string;
  regionId: string;
}

export interface RunRefineDeps {
  confirmThreshold: number;
  getQueryImagePath: (searchId: string) => Promise<string>;
  expandRegion: (regionId: string) => Promise<RegionCandidate[]>;
  readImage: (path: string) => Promise<string | null>;
  verify: (queryBase64: string, candidateBase64: string[]) => Promise<VerifyResult[]>;
  persist: (args: PersistRefineArgs) => Promise<SearchCandidate[]>;
  // Called after each candidate finishes verifying (verified count, total),
  // so a caller (the refine route's SSE stream) can report live progress and
  // an ETA to the frontend. Optional so existing tests/callers that don't
  // care about progress don't need to pass a no-op.
  onProgress?: (verified: number, total: number) => void;
}

// RoMa (Laila) verification is dense pairwise matching — MUCH more expensive
// per image than a Lumi Preview embedding. Sending all of a region's
// candidates (seen live: 44) in one /verify call meant one blocking request
// that could run for many minutes with zero feedback, reading as "colgado".
// Chunk size is 1, not a batch — services/inference/main.py's own /verify
// handler already loops over candidates ONE AT A TIME internally regardless
// of how many are sent per request (no batched/parallel matching happens
// there), so a bigger chunk buys nothing but fewer, longer-hanging HTTP
// calls. Chunking by 1 costs nothing extra in total processing time and
// gives onProgress a real per-candidate checkpoint to report to the
// frontend (spec: live progress + ETA during refine).
const VERIFY_CHUNK_SIZE = 1;

/** Pass 2 orchestration (spec §9.3). Missing-image candidates are skipped, not dropped silently. */
export async function runRefine(deps: RunRefineDeps, input: RunRefineInput): Promise<RefineResponse> {
  const queryPath = await deps.getQueryImagePath(input.searchId);
  const queryBase64 = await deps.readImage(queryPath);
  if (queryBase64 === null) {
    throw new Error(`Query image missing for search ${input.searchId} at ${queryPath}`);
  }

  const region = await deps.expandRegion(input.regionId);

  // Pair each candidate with its image; keep only those whose image is present.
  const present: { candidate: RegionCandidate; base64: string }[] = [];
  let skipped = 0;
  for (const candidate of region) {
    const base64 = candidate.imagePath ? await deps.readImage(candidate.imagePath) : null;
    if (base64 === null) {
      skipped += 1;
      continue;
    }
    present.push({ candidate, base64 });
  }

  if (skipped > 0) {
    // Visible, not silent (Global Constraints): areas indexed before Pass 2 have no image.
    console.warn(`runRefine: skipped ${skipped} candidate(s) with no stored image (reindex to verify).`);
  }

  if (present.length === 0) {
    const candidates = await deps.persist({
      searchId: input.searchId,
      regionId: input.regionId,
      scored: [],
      confirmThreshold: deps.confirmThreshold,
    });
    return { searchId: input.searchId, regionId: input.regionId, candidates };
  }

  console.log(`[run-refine] verificando ${present.length} candidatos para la región ${input.regionId} en lotes de ${VERIFY_CHUNK_SIZE}`);
  deps.onProgress?.(0, present.length);

  const results: Awaited<ReturnType<RunRefineDeps["verify"]>> = [];
  for (let start = 0; start < present.length; start += VERIFY_CHUNK_SIZE) {
    const chunk = present.slice(start, start + VERIFY_CHUNK_SIZE);
    const chunkResults = await deps.verify(
      queryBase64,
      chunk.map((p) => p.base64)
    );
    results.push(...chunkResults);
    console.log(`[run-refine] verificados ${results.length}/${present.length}`);
    deps.onProgress?.(results.length, present.length);
  }

  const scored: ScoredCandidate[] = present.map((p, i) => ({
    indexedImageId: p.candidate.indexedImageId,
    panoId: p.candidate.panoId,
    heading: p.candidate.heading,
    lat: p.candidate.lat,
    lng: p.candidate.lng,
    similarityScore: 0, // Pass 2 ranks by verification; similarity already stored from Pass 1
    verificationScore: results[i].score,
  }));

  const candidates = await deps.persist({
    searchId: input.searchId,
    regionId: input.regionId,
    scored,
    confirmThreshold: deps.confirmThreshold,
  });
  return { searchId: input.searchId, regionId: input.regionId, candidates };
}