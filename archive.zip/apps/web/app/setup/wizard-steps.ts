// apps/web/app/setup/wizard-steps.ts
export const WIZARD_STEPS = [
  { id: "install", title: "Instalación" },
  { id: "database", title: "Base de datos" },
  { id: "credentials", title: "Credenciales" },
  { id: "confirm", title: "Confirmación" },
] as const;
export type StepId = (typeof WIZARD_STEPS)[number]["id"];
const idx = (id: StepId) => WIZARD_STEPS.findIndex((s) => s.id === id);
export function nextStep(id: StepId): StepId | null {
  const i = idx(id);
  return i >= 0 && i < WIZARD_STEPS.length - 1 ? WIZARD_STEPS[i + 1].id : null;
}
export function prevStep(id: StepId): StepId | null {
  const i = idx(id);
  return i > 0 ? WIZARD_STEPS[i - 1].id : null;
}
export function isComplete(id: StepId): boolean { return id === "confirm"; }