"use client";

import { useEffect, useState } from "react";
import { MapCanvas } from "./MapCanvas";
// Se remueve ImageDropzone y se importan los nuevos primitivos de arrastre del mapa
import { MapDropTarget } from "./MapDropTarget";
import { UploadPopup } from "./UploadPopup";
import { ConfidenceCircleLayer } from "./ConfidenceCircleLayer";
import { ResultsPanel } from "./ResultsPanel";
import { TopResultCard } from "./TopResultCard";
import { BottomSummaryBar } from "./BottomSummaryBar";
import { useSearchStore } from "../stores/useSearchStore";
import { useMapStore } from "../stores/useMapStore";
import { fetchJson } from "../lib/fetch-json";

// Debe coincidir con el contrato `Selected` de UploadPopup ({ file, url }).
interface SelectedFile {
  file: File;
  url: string;
}

function formatEta(etaMs: number | null): string {
  if (etaMs === null) return "calculando…";
  const totalSeconds = Math.round(etaMs / 1000);
  if (totalSeconds < 60) return `~${totalSeconds}s`;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `~${minutes}m ${seconds}s`;
}

export function SearchDashboard() {
  const [map, setMap] = useState<any>(null);
  const [queryImageUrl, setQueryImageUrl] = useState<string | null>(null);
  const { refineStatus, refineProgress, regions, error, setSearching, setSearchResults, setError } = useSearchStore();
  const setMode = useMapStore((s) => s.setMode);

  // Estado local para capturar el archivo arrastrado sobre el lienzo del mapa
  const [selected, setSelected] = useState<SelectedFile[]>([]);

  useEffect(() => {
    setMode("search");
  }, [setMode]);

  // Manejador centralizado modificado para aceptar la referencia directa del File
  async function handleImage(file: File) {
    setQueryImageUrl(URL.createObjectURL(file));
    setSearching(file.name);
    const form = new FormData();
    form.append("image", file);
    const { ok, data } = await fetchJson("/api/search", { method: "POST", body: form });
    if (!ok || !data) return setError(data?.error ?? "La búsqueda falló");
    setSearchResults(data, file.name);
  }

  const { currentSearchId, setRefining, setRefineProgress, setRefineResults, selectRegion } = useSearchStore();

  // Streamed as SSE, not a single fetchJson call — refine can take minutes
  // (RoMa verification is ~10-25s PER CANDIDATE), so the route reports
  // progress/ETA per candidate as it goes (see the refine route's onProgress
  // wiring). Same parsing shape as useCommandRun.ts's setup-wizard SSE
  // consumer, just with refine-specific event types instead of log lines.
  async function handleRefine(regionId: string) {
    if (!currentSearchId) return;
    selectRegion(regionId);
    setRefining();

    const res = await fetch(`/api/search/${currentSearchId}/refine`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ regionId }),
    });
    if (!res.ok || !res.body) return setError(`El refinado falló (HTTP ${res.status})`);

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const parts = buffer.split("\n\n");
      buffer = parts.pop() ?? "";
      for (const part of parts) {
        const raw = part.replace(/^data: /, "");
        if (!raw) continue;
        const event = JSON.parse(raw) as
          | { type: "progress"; verified: number; total: number; etaMs: number | null }
          | { type: "done"; result: { candidates: import("@netryx/shared-types").SearchCandidate[] } }
          | { type: "error"; message: string };
        if (event.type === "progress") {
          setRefineProgress({ verified: event.verified, total: event.total, etaMs: event.etaMs });
        } else if (event.type === "done") {
          setRefineResults(regionId, event.result.candidates);
        } else if (event.type === "error") {
          setError(event.message);
        }
      }
    }

    const region = regions.find((r) => r.id === regionId);
    if (map && region) {
      map.flyTo({ center: [region.centroid.lng, region.centroid.lat], zoom: 16, pitch: 55, duration: 900 });
    }
  }

  // Ajuste de encuadre (Fit Bounds) automático
  useEffect(() => {
    if (!map || regions.length === 0) return;
    const lngs = regions.map((r) => r.centroid.lng);
    const lats = regions.map((r) => r.centroid.lat);
    map.fitBounds(
      [
        [Math.min(...lngs), Math.min(...lats)],
        [Math.max(...lngs), Math.max(...lats)],
      ],
      { padding: 120, maxZoom: 14, duration: 800 }
    );
  }, [map, regions]);

  // Interceptores de archivos arrojados en la zona global del mapa
  function handleFilesDropped(files: File[]) {
    if (files.length === 0) return;
    const formatted = files.map((file) => ({ file, url: URL.createObjectURL(file) }));
    setSelected((prev) => [...prev, ...formatted]);
  }

  function handleRemove(index: number) {
    setSelected((prev) => {
      const next = [...prev];
      const [removed] = next.splice(index, 1);
      if (removed) URL.revokeObjectURL(removed.url);
      return next;
    });
  }

  function handleTriggerSearch() {
    if (selected.length === 0) return;
    // Backend is single-image: search the first selected file (documented limit).
    handleImage(selected[0].file);
    selected.forEach((s) => URL.revokeObjectURL(s.url));
    setSelected([]);
  }

  const idle = refineStatus === "idle";
  const searching = refineStatus === "searching";
  const refining = refineStatus === "refining";

  return (
    <>
      <MapCanvas onReady={(m) => setMap(m)} />
      {map && <ConfidenceCircleLayer map={map} />}

      {/* Se expone de forma permanente sobre el mapa en estado idle el capturador drag-and-drop */}
      {idle && <MapDropTarget onFiles={handleFilesDropped} />}

      {/* Popup modal reactivo cuando existe al menos un archivo cargado en memoria */}
      {selected.length > 0 && (
        <UploadPopup
          files={selected}
          onAddMore={handleFilesDropped}
          onRemove={handleRemove}
          onSearch={handleTriggerSearch}
          busy={searching}
        />
      )}

      {searching && (
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-card bg-panel/80 px-5 py-3 text-sm text-fg backdrop-blur-md z-40">
          Localizando…
        </div>
      )}

      {regions.length > 0 && (
        <>
          <TopResultCard onRefine={handleRefine} refining={refining} />
          <div className="absolute right-0 top-0 h-full">
            <ResultsPanel queryImageUrl={queryImageUrl} onRefine={handleRefine} refining={refining} />
          </div>
          <BottomSummaryBar />
        </>
      )}

      {/* Sin esto, "refinar" corría en segundo plano sin ningún indicador —
          con muchos resultados el cambio pasa desapercibido y parece que el
          botón no hace nada. Progreso y ETA vienen del SSE de la ruta de
          refine (ver handleRefine) — RoMa verifica ~10-25s por candidato, así
          que sin esto una región de 8+ candidatos parece colgada varios
          minutos. */}
      {refining && (
        <div className="absolute left-1/2 top-1/2 z-40 w-72 -translate-x-1/2 -translate-y-1/2 rounded-card bg-panel/80 px-5 py-4 text-sm text-fg backdrop-blur-md">
          <div className="flex items-center justify-between">
            <span>Refinando…</span>
            {refineProgress && (
              <span className="text-xs text-muted">
                {refineProgress.verified}/{refineProgress.total}
              </span>
            )}
          </div>
          {refineProgress && (
            <>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-accent transition-all"
                  style={{
                    width: `${refineProgress.total > 0 ? (refineProgress.verified / refineProgress.total) * 100 : 0}%`,
                  }}
                />
              </div>
              <div className="mt-1.5 text-xs text-muted">
                Tiempo restante estimado: {formatEta(refineProgress.etaMs)}
              </div>
            </>
          )}
        </div>
      )}

      {error && (
        <div className="absolute left-1/2 top-4 -translate-x-1/2 rounded-card bg-danger/20 px-4 py-2 text-xs text-danger-fg z-50">
          {error}
        </div>
      )}
    </>
  );
}