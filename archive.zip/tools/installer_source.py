# tools/installer_source.py
"""
Source for LumiInstaller.exe (compiled by tools/build.py via PyInstaller —
see Task 4). This file is not meant to be run directly by end users; it's
the entry point PyInstaller packages into a single .exe that ends up at the
ROOT of the distributed project folder (next to package.json, apps/, etc.),
placed there by tools/build.py's staging step.

What it does: checks Node.js/pnpm/Python/Docker are on PATH, creates .env
from .env.example if missing, runs `pnpm install`, starts Postgres via
`docker compose`, starts the inference service (native venv or WSL2, per
data/runtime-config.json written by setup — see service_launcher.py) and the
worker, then starts the web app and opens the browser on it. Inference/worker
are skipped with a printed message if their setup step hasn't run yet (fresh
clone, first launch) — the web app still comes up so /setup can run.

What it deliberately does NOT do: reimplement the app's own setup wizard
(Install/Database/Credentials/Confirm at /setup, already built — see
apps/web/app/setup/SetupWizard.tsx). This script's job ends the moment the
dev server is up; the wizard takes over from there, exactly as it already
does for anyone who runs `pnpm dev` by hand (see
apps/web/app/(protected)/gate.ts — any protected route redirects to /setup
until setup is completed).
"""
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from service_launcher import start_all_services  # noqa: E402

REQUIRED_TOOLS = ["node", "pnpm", "python", "docker"]


def project_root() -> Path:
    if getattr(sys, "frozen", False):
        # Running as the compiled LumiInstaller.exe: PyInstaller sets
        # sys.frozen=True and sys.executable to the exe's own real path.
        # tools/build.py places that exe at the project root when staging,
        # so its own directory IS the project root.
        return Path(sys.executable).resolve().parent
    # Running as plain `python tools/installer_source.py` (dev testing):
    # tools/installer_source.py -> tools -> repo root.
    return Path(__file__).resolve().parent.parent


def missing_tools() -> list[str]:
    return [t for t in REQUIRED_TOOLS if shutil.which(t) is None]


def run(cmd: list[str], cwd: Path) -> int:
    print(f"$ {' '.join(cmd)}")
    return subprocess.call(cmd, cwd=cwd, shell=(sys.platform == "win32"))


def main() -> int:
    root = project_root()

    missing = missing_tools()
    if missing:
        print("Faltan estas herramientas en tu PATH:", ", ".join(missing))
        print("Instálalas (Node.js + pnpm, Python 3, Docker Desktop) y vuelve a ejecutar LumiInstaller.exe.")
        return 1

    env_path = root / ".env"
    example_path = root / ".env.example"
    if not env_path.exists() and example_path.exists():
        shutil.copy2(example_path, env_path)
        print(f"Creado {env_path} a partir de .env.example — puedes editarlo antes de continuar si quieres.")

    if run(["pnpm", "install"], cwd=root) != 0:
        print("pnpm install falló — revisa el error de arriba.")
        return 1

    if run(["docker", "compose", "up", "-d", "--build", "db"], cwd=root) != 0:
        print("No se pudo arrancar Postgres — ¿está Docker Desktop corriendo?")
        return 1

    print("\nArrancando servicio de inferencia y worker...")
    start_all_services(root, log=print)

    print("\nTodo listo. Arrancando la web en http://localhost:3000 ...")
    print("La primera vez te llevará automáticamente al asistente de instalación (/setup).")
    webbrowser.open("http://localhost:3000")
    return run(["pnpm", "--filter", "@netryx/web", "dev"], cwd=root)


if __name__ == "__main__":
    raise SystemExit(main())