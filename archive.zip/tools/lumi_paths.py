# tools/lumi_paths.py
"""
Pure helpers for tools/build.py: what counts as "the project" for a
distributable bundle. No side effects, no subprocess calls.
"""
import json
from pathlib import Path

# Repo-relative top-level entries to walk when staging a bundle (Task 4).
# Anything not listed here never makes it into a bundle, regardless of
# BUNDLE_EXCLUDE_DIR_NAMES below (that set only prunes WITHIN these).
BUNDLE_INCLUDE = [
    "apps/web",
    "apps/worker",
    "packages",
    "db",
    "services/inference",
    "docs",
    "tools",
    "package.json",
    "pnpm-workspace.yaml",
    "pnpm-lock.yaml",
    "docker-compose.yml",
    ".env.example",
    "README.md",
]

# Mirrors .gitignore's intent (repo root .gitignore) — dev-only, generated,
# or multi-GB directories that must never end up in a distributable bundle.
BUNDLE_EXCLUDE_DIR_NAMES = {
    "node_modules",
    ".next",
    "venv",
    "venv-wsl",
    ".pip-cache",
    ".pip-cache-wsl",
    "__pycache__",
    "data",
    ".git",
    "dist",
}


def read_version(root: Path) -> str:
    data = json.loads((root / "package.json").read_text(encoding="utf-8"))
    return data["version"]